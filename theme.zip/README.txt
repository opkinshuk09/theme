Professional Theme
==================
Thank you for purchasing the Professional theme!

 - For installation and update instructions, read the INSTALL.txt file.
 - For support, you can go to my Discord server: https://discord.gg/Zjvvdrs8Vm (preferred)
   OR you can email me at me@omame.xyz (response isn't guaranteed).

TERMS AND CONDITIONS
====================
1. You may not use parts of the theme's source code outside of the theme.
2. You may not resell or republish parts of the theme's source code or the theme's
   binaries, including the theme in its entirety.
3. Maintenance and support (incl. Pterodactyl updates) are not guaranteed.
4. Compatibility with any plugins is not guaranteed.
5. I'm allowed to refuse support if I believe the Terms and Conditions were
   violated by you in any way.
